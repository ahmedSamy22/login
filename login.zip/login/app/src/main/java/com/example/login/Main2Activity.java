package com.example.login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView txt =(TextView) findViewById(R.id.us);
        TextView txt2 =(TextView) findViewById(R.id.pa);
        Bundle b=getIntent().getExtras();

        String user =b.getString("userName");
        String pass=b.getString("password");

        txt.setText("usernme = "+user);
        txt2.setText("password = "+pass);
    }
}