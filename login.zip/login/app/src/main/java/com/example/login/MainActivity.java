package com.example.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void loginclick(View view) {

        EditText userName= (EditText) findViewById(R.id.user);
        EditText userPass= (EditText) findViewById(R.id.pass);


        if(userName.getText().toString().equals("ahmed")&&userPass.getText().toString().equals("123456"))
        {

                Toast.makeText(getApplicationContext(),"Welcome",Toast.LENGTH_LONG).show();
            Intent myintent =new Intent(this,Main2Activity.class);

            Bundle b=new Bundle();
            b.putString("userName",userName.getText().toString());
            b.putString("password",userPass.getText().toString());
            myintent.putExtras(b);

            startActivity(myintent);
        }
       else if(userName.getText().toString().equals("ahmed"))
        {
            int x= 0;
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Wrong Username",Toast.LENGTH_LONG).show();
        }
        if(userPass.getText().toString().equals("123456"))
        {
            int x=1;
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Wrong Password",Toast.LENGTH_LONG).show();
        }








    }



}
